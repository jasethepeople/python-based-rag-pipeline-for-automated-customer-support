---
name: customer-support-review-desk-alerting
description: Build or extend an authenticated customer-support feedback Review Desk with durable feedback capture, AI sentiment labels with safe fallback, server-filtered reporting, negative-feedback spike monitoring, timestamped spike history, and local-first alert settings. Use when creating support answer feedback workflows, admin review dashboards, feedback analytics, or alerting based on real customer feedback.
---

# Customer Support Review Desk Alerting

Build a support-feedback system that is **truthful, reviewable, and safe to operate**. Use real persisted feedback for dashboards and alert history. Do not seed, fabricate, or hardcode customer reviews, ratings, comments, alert records, or testimonials.

## Workflow

1. **Establish the data contract.** Define persistent feedback fields, review workflow fields, and reporting filters before writing dashboard UI.
2. **Implement secure capture and review.** Submit feedback through an authenticated/protected server procedure as appropriate; gate the Review Desk with an admin role.
3. **Add sentiment safely.** Classify written feedback on the server. Persist both the label and its source; provide a rating-derived fallback when a comment is absent or classification fails.
4. **Use one filtered report source.** Have list, metrics, distribution, trend, CSV export, spike monitor, and history consume the same server-filtered record set.
5. **Add alert analysis.** Aggregate real feedback by week or month, compare the newest period with a weighted trailing baseline, and refuse to claim a meaningful alert without enough history.
6. **Add a reconstructed history.** Derive historical qualifying spikes from the selected feedback periods and timestamp each entry from the latest captured feedback in its flagged period. Label it as reconstructed, not a notification inbox.
7. **Keep dashboard preferences local-first.** Persist page size, sorting, saved views, comparison window, and history retention in browser storage unless the user explicitly asks for account-shared settings.
8. **Verify without invented customers.** Test pure aggregation and threshold logic with aggregate period values, mock empty server results only, and render component states without inserting feedback records.
9. **Document and checkpoint.** Add an admin runbook, complete the project todo, run tests/type-check/build, visually inspect desktop and mobile states, then save a checkpoint.

## Non-Negotiable Rules

| Rule | Apply it this way |
|---|---|
| **No fabricated feedback** | Never insert test feedback into the production/shared database. Do not show made-up reviews, ratings, or alert rows. |
| **Server authority** | Persist feedback, review states, filters, report totals, and CSV exports through protected server procedures. |
| **Transparent AI** | Store `sentiment` and `sentimentSource` such as `ai` or `fallback`. Do not imply AI certainty when fallback is used. |
| **Local-first settings** | Keep display and analysis preferences in browser storage by default. Explain that they do not alter feedback records. |
| **Scoped honesty** | If a filter narrows the population, state that the monitor/history is scoped or suppress an overall claim. |
| **Accessible states** | Give alerts semantic `role="alert"` only when triggered; use `role="status"` for calibrating/stable states. Label all controls and provide text summaries for charts. |

## Data and Procedure Blueprint

Read [references/implementation-contract.md](references/implementation-contract.md) before creating schema or API changes. Keep each layer aligned:

| Layer | Required outcome |
|---|---|
| Database | Feedback identity, query, answer, rating, optional comment, timestamps, sentiment/source, reviewer metadata. |
| Server | Protected submit/list/report/export/update procedures; centralized filtering and metrics. |
| Client | Support feedback controls, Review Desk filters, distribution/trend, workflow controls, alert views, local settings. |
| Tests | Behavior contracts, pure aggregate analysis, rendered empty/stable/spike/scoped states, local setting persistence. |

## Sentiment Workflow

1. Normalize an optional written comment.
2. If non-empty, call the configured server-side structured-output model and constrain the result to `positive`, `neutral`, or `negative`.
3. Persist `sentimentSource: "ai"` only after a valid model result.
4. If there is no comment or an AI failure, derive a documented rating-based label and persist `sentimentSource: "fallback"`.
5. Never block feedback capture merely because AI classification fails.
6. Expose both fields in the protected report, Review Desk badge/detail view, sentiment filter, and CSV export.

## Spike-Monitor Workflow

Use the same current report filter set for the monitor, history, chart, and export. Aggregate records into period objects:

```ts
type Period = {
  label: string;
  positive: number;
  negative: number;
  observedAt: string; // latest real feedback timestamp in the period
};
```

For the current period, calculate the baseline from the preceding configured comparison window. Weight baseline rates by total records, rather than averaging period percentages.

```ts
baselineRate = sum(previous.negative) / sum(previous.positive + previous.negative)
latestRate = latest.negative / (latest.positive + latest.negative)
change = latestRate - baselineRate
```

Default conservative gates are: at least **three** current-period signals, at least **two** negative signals, a negative rate of at least **50%**, and an increase of at least **25 percentage points** over baseline. Make thresholds explicit and configurable only if the user asks; do not silently tune them.

When fewer than `comparisonWindow + 1` populated periods exist, show **Calibrating**. Do not display an alert or fabricate history.

## History and Settings

Reconstruct history by evaluating each historical period against the prior periods available at that point in time. Retain only the configured recent analysis window, newest first. For each item show the period label, the latest real feedback timestamp in that period, current negative count/rate, and baseline-point increase.

Offer only bounded settings unless custom thresholds are explicitly requested:

| Setting | Suggested choices | Meaning |
|---|---|---|
| Comparison window | 2, 3, or 4 prior periods | Trailing baseline size. |
| History retention | 3, 6, or 12 recent periods | Maximum reconstruction window. |

Validate values at read and write time. Persist settings using a small adapter around browser storage so defaults, invalid JSON, persistence, and reset behavior can be unit-tested.

## Verification Checklist

Complete all applicable checks before delivery:

- [ ] No feedback records, alerts, or testimonials were fabricated or seeded.
- [ ] Database schema and actual migration agree.
- [ ] Feedback procedures are authenticated and Review Desk procedures are admin-gated.
- [ ] Empty, stable, calibrating, spike, and scoped states are truthful and accessible.
- [ ] CSV includes the same sentiment and metadata represented in the Review Desk.
- [ ] Aggregate-only tests cover fallback, filter contracts, weighted baseline, configurable windows, history ordering, and retention.
- [ ] UI tests cover settings changes, reset defaults, and rendered alert/history states.
- [ ] Desktop and mobile screenshots were inspected.
- [ ] Full test suite, type-check, and production build pass.
- [ ] Project todo is current and a checkpoint is saved.

## When to Branch

**Need account-shared settings?** Add a schema-backed admin preferences model, protected update/read procedures, migration, and authorization checks; do not reuse browser-local storage as a shared source of truth.

**Need real-time or scheduled alerts?** Read the relevant periodic-work or automation guidance first. Keep the dashboard’s reconstructed history distinct from a durable notification-event ledger.

**Need an alert acknowledgement workflow?** Add durable fields such as `acknowledgedAt`, `acknowledgedBy`, and `resolutionNote` to a real alert-event table. Do not mutate reconstructed historical calculations to impersonate stored alert events.

## Delivery

Summarize the data flow, safeguards, configurable windows, and verification count. Explicitly say that no customer feedback was fabricated. Attach the final project checkpoint and provide a short admin guide when operators will use the alert controls.
