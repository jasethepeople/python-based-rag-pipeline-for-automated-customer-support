# Implementation Contract

Use this reference before extending a customer-support Review Desk. Adapt names to the existing stack, but preserve the responsibilities.

## Suggested Persistent Feedback Fields

| Field | Purpose |
|---|---|
| `publicId` | Safe client-facing record identifier. |
| `query`, `answer` | Captured support interaction context. |
| `rating`, `comment` | Original feedback input. |
| `sentiment`, `sentimentSource` | Positive/neutral/negative result and `ai` or `fallback` provenance. |
| `issueCategory`, `reviewStatus`, `reviewerNote`, `pinned` | Admin review workflow. |
| `createdAt`, `updatedAt`, `reviewedAt` | UTC audit times. |

## Protected Procedure Surface

| Procedure | Responsibility |
|---|---|
| `submit` | Validate feedback, classify safely, persist it, and notify on eligible negative feedback. |
| `list` | Return paginated admin records using server-side filters. |
| `report` | Return the single filtered record/metric source for charts and analytics. |
| `exportCsv` | Generate server-side CSV from the same report inputs. |
| `updateReview` | Update admin workflow state with authorization. |
| `alertSummary` | Return only truthful unresolved-alert counts; do not synthesize customer data. |

## Filter Contract

Pass a stable, explicit filter object to all analytics consumers. Typical keys are rating, sentiment, review status, issue category, keyword, saved view, sort, and inclusive date range. Reset pagination/selection when any scope-setting input changes.

If an alert is described as an **overall feedback** alert, suppress it whenever any input narrows the population. If a scoped alert is permitted, label the active scope next to the monitor and history.

## Test Strategy Without Customer Fixtures

Use three test layers:

1. **Pure analysis tests.** Supply aggregate period totals and timestamps; assert rates, thresholds, ordering, calibration, retention, and configurable comparison windows.
2. **Server contract tests.** Mock database helpers to return empty arrays or schema-shaped outputs. Assert protected procedures accept filters and exports include required headers.
3. **Rendered component tests.** Render calibrating, stable, spike, scoped, empty-history, populated-history, settings-change, and reset-default states. Do not insert a review, comment, rating, or alert record.

Do not test the live AI classification path using an invented customer submission. Test the fallback contract and validate the live call naturally when genuine feedback arrives.
