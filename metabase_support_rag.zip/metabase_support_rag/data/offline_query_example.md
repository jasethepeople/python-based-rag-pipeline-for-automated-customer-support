**Confidence: high**

Generation is unavailable, so here are the most relevant retrieved excerpts rather than an unsupported synthesized answer.

- **Metabot in Slack** [S1]: v0.63 v0.62 v0.61 v0.60 v0.59 v0.58 lts v0.57 unsupported v0.56 unsupported v0.55 unsupported v0.54 unsupported See more Whatâs new Metabot in Slack Chat with Metabot in Slack. Direct message Metabot for private analysis, or mention @Metabot in a channel to collaborate with your team. What Metabot can do From Slack you can ask Metabot to: Find existing content : Search your Metabase for questions and dashboards. Me…
- **Metabot - Metabaseâs AI assistant** [S2]: to open up the chat sidebar . Click the Metabot icon in top right. You can chat with Metabot (though predictably, itâs only interested in helping you answer questions about your data). Metabot will keep the context of the current question with each new prompt. Only the current conversation history is saved (you can scroll up to see it). If you start a new chat, Metabase will discard the previous conversation, so be…
- **AI settings** [S3]: verified-content setting, allowed collection, and prompt suggestions, all configured independently. Enable Metabot Internal tab. Toggle Metabot on or off for your Metabase. Metabot is enabled by default. When enabled, Metabot is available to help people create questions, analyze data, and answer questions about your data. When disabled, the Metabot icon and keyboard shortcuts are hidden. To scope Metabot to specific …

### Exact source links
[S1] [Metabot in Slack](https://www.metabase.com/docs/latest/ai/metabot-slack) — Official documentation
[S2] [Metabot - Metabaseâs AI assistant](https://www.metabase.com/docs/latest/ai/metabot) — Official documentation
[S3] [AI settings](https://www.metabase.com/docs/latest/ai/settings) — Official documentation
[S4] [AI in Metabase overview](https://www.metabase.com/docs/latest/ai/overview) — Official documentation
